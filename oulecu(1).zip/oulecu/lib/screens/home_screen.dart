import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';
import '../providers/app_state_provider.dart';
import '../theme/app_theme.dart';
import '../widgets/gold_input.dart';
import '../widgets/text_editor_tools.dart';
import '../widgets/custom_button.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  late TextEditingController _topicController;
  late TextEditingController _subtopicController;
  late TextEditingController _contentController;
  final ImagePicker _imagePicker = ImagePicker();

  @override
  void initState() {
    super.initState();
    final appState = context.read<AppStateProvider>();
    _topicController = TextEditingController(text: appState.topic);
    _subtopicController = TextEditingController(text: appState.subtopic);
    _contentController = TextEditingController(text: appState.content);
  }

  @override
  void dispose() {
    _topicController.dispose();
    _subtopicController.dispose();
    _contentController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<AppStateProvider>(
      builder: (context, appState, child) {
        return Scaffold(
          backgroundColor: AppColors.background,
          appBar: AppBar(
            title: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Image.asset(
                  'assets/images/logo.png',
                  width: 28,
                  height: 28,
                  errorBuilder: (_, __, ___) => const Icon(
                    Icons.image,
                    color: AppColors.primaryGold,
                    size: 28,
                  ),
                ),
                const SizedBox(width: 10),
                const Text('OULECU'),
              ],
            ),
            actions: [
              // Theme toggle
              IconButton(
                icon: const Icon(Icons.dark_mode),
                tooltip: 'Theme',
                onPressed: () {},
              ),
              // Quick action
              IconButton(
                icon: const Icon(Icons.bolt),
                tooltip: 'Quick Action',
                onPressed: () {},
              ),
              const SizedBox(width: 8),
            ],
          ),
          body: SafeArea(
            child: Column(
              children: [
                // Content area
                Expanded(
                  child: SingleChildScrollView(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // Topic input
                        GoldInput(
                          label: 'TOPIC',
                          hint: 'Enter topic...',
                          controller: _topicController,
                          onChanged: appState.setTopic,
                          textInputAction: TextInputAction.next,
                        ),
                        const SizedBox(height: 12),
                        // Subtopic input
                        GoldInput(
                          label: 'SUBTOPIC',
                          hint: 'Enter subtopic...',
                          controller: _subtopicController,
                          onChanged: appState.setSubtopic,
                          textInputAction: TextInputAction.next,
                        ),
                        const SizedBox(height: 16),
                        // Content text area
                        _buildContentArea(appState),
                        const SizedBox(height: 12),
                        // Text editing tools
                        TextEditorTools(
                          isBold: appState.cardConfig.fontWeight == FontWeight.bold,
                          isItalic: appState.cardConfig.fontStyle == FontStyle.italic,
                          textAlign: appState.cardConfig.textAlign,
                          fontSize: appState.cardConfig.fontSize,
                          onBoldToggle: (isBold) {
                            appState.setFontWeight(
                              isBold ? FontWeight.bold : FontWeight.normal,
                            );
                          },
                          onItalicToggle: (isItalic) {
                            appState.setFontStyle(
                              isItalic ? FontStyle.italic : FontStyle.normal,
                            );
                          },
                          onAlignChange: appState.setTextAlign,
                          onFontSizeChange: appState.setFontSize,
                          onImagePick: () => _showImagePicker(context, appState),
                          onUndo: appState.undo,
                          onRedo: appState.redo,
                          canUndo: appState.canUndo,
                          canRedo: appState.canRedo,
                        ),
                      ],
                    ),
                  ),
                ),
                // Bottom action bar
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: AppColors.surface,
                    border: const Border(
                      top: BorderSide(color: AppColors.borderMuted, width: 1),
                    ),
                  ),
                  child: SafeArea(
                    child: Row(
                      children: [
                        DiscardButton(
                          onDiscard: () {
                            _topicController.clear();
                            _subtopicController.clear();
                            _contentController.clear();
                            appState.setTopic('');
                            appState.setSubtopic('');
                            appState.setContent('');
                          },
                        ),
                        const Spacer(),
                        SizedBox(
                          width: 140,
                          child: GoldButton(
                            label: 'NEXT',
                            onPressed: _contentController.text.isNotEmpty ||
                                    appState.cardConfig.contentImageBytes != null
                                ? () {
                                    appState.setTopic(_topicController.text);
                                    appState.setSubtopic(_subtopicController.text);
                                    appState.setContent(_contentController.text);
                                    appState.goNext();
                                  }
                                : null,
                            icon: Icons.arrow_forward,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildContentArea(AppStateProvider appState) {
    return Container(
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: AppColors.borderMuted, width: 1),
      ),
      child: Column(
        children: [
          // Content image (if any)
          if (appState.cardConfig.contentImageBytes != null)
            Stack(
              children: [
                ClipRRect(
                  borderRadius: const BorderRadius.vertical(
                    top: Radius.circular(8),
                  ),
                  child: Image.memory(
                    appState.cardConfig.contentImageBytes!,
                    width: double.infinity,
                    height: 200,
                    fit: BoxFit.cover,
                  ),
                ),
                Positioned(
                  top: 8,
                  right: 8,
                  child: GestureDetector(
                    onTap: () => appState.setContentImage(null, null),
                    child: Container(
                      padding: const EdgeInsets.all(4),
                      decoration: const BoxDecoration(
                        color: AppColors.error,
                        shape: BoxShape.circle,
                      ),
                      child: const Icon(
                        Icons.close,
                        size: 16,
                        color: Colors.white,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          // Content text field
          GoldTextArea(
            label: 'CONTENT',
            hint: 'Type your content here... (emojis supported)',
            controller: _contentController,
            onChanged: (value) {
              appState.setContent(value);
            },
            maxLines: 12,
          ),
        ],
      ),
    );
  }

  void _showImagePicker(BuildContext context, AppStateProvider appState) {
    showModalBottomSheet(
      context: context,
      backgroundColor: AppColors.surface,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (context) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                'INSERT IMAGE',
                style: Theme.of(context).textTheme.labelLarge,
              ),
              const SizedBox(height: 24),
              ListTile(
                leading: const Icon(Icons.photo_library, color: AppColors.primaryGold),
                title: const Text(
                  'Gallery',
                  style: TextStyle(color: AppColors.textPrimary),
                ),
                subtitle: const Text(
                  'Choose from your photos',
                  style: TextStyle(color: AppColors.textMuted, fontSize: 12),
                ),
                onTap: () async {
                  Navigator.pop(context);
                  final picked = await _imagePicker.pickImage(
                    source: ImageSource.gallery,
                  );
                  if (picked != null) {
                    final bytes = await picked.readAsBytes();
                    appState.setContentImage(picked.path, bytes);
                  }
                },
              ),
              const Divider(color: AppColors.divider),
              ListTile(
                leading: const Icon(Icons.camera_alt, color: AppColors.primaryGold),
                title: const Text(
                  'Camera',
                  style: TextStyle(color: AppColors.textPrimary),
                ),
                subtitle: const Text(
                  'Take a new photo',
                  style: TextStyle(color: AppColors.textMuted, fontSize: 12),
                ),
                onTap: () async {
                  Navigator.pop(context);
                  final picked = await _imagePicker.pickImage(
                    source: ImageSource.camera,
                  );
                  if (picked != null) {
                    final bytes = await picked.readAsBytes();
                    appState.setContentImage(picked.path, bytes);
                  }
                },
              ),
              const SizedBox(height: 16),
            ],
          ),
        ),
      ),
    );
  }
}
