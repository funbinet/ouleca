import 'dart:io';
import 'dart:typed_data';
import 'dart:ui' as ui;
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:image/image.dart' as img;
import '../models/card_config.dart';
import '../models/template.dart';
import 'storage_service.dart';

class RenderService {
  static final RenderService _instance = RenderService._internal();
  factory RenderService() => _instance;
  RenderService._internal();

  final StorageService _storage = StorageService();

  Future<List<String>> renderCards(
    CardConfig config,
    List<Template> templates,
    List<String> formats,
  ) async {
    final List<String> generatedFiles = [];

    for (int i = 0; i < templates.length; i++) {
      final template = templates[i];
      for (final format in formats) {
        try {
          final bytes = await _renderCardImage(config, template);
          if (bytes != null) {
            final fileName = 'oulecu_${template.id}_${DateTime.now().millisecondsSinceEpoch}.$format'.toLowerCase();
            final filePath = await _storage.saveImage(bytes, fileName);
            generatedFiles.add(filePath);
          }
        } catch (e) {
          debugPrint('Error rendering card: $e');
        }
      }
    }

    return generatedFiles;
  }

  Future<Uint8List?> _renderCardImage(CardConfig config, Template template) async {
    final width = config.cardWidth.toInt();
    final height = config.cardHeight.toInt();

    final recorder = ui.PictureRecorder();
    final canvas = Canvas(recorder);

    // 1. Draw background
    _drawBackground(canvas, config, template, width, height);

    // 2. Draw border
    _drawBorder(canvas, config, width, height);

    // 3. Draw shadow
    if (config.shadowEnabled) {
      _drawShadow(canvas, config, width, height);
    }

    // 4. Draw avatar & name/handle
    await _drawUserInfo(canvas, config, width);

    // 5. Draw logo
    await _drawLogo(canvas, config, template, width, height);

    // 6. Draw topic & subtopic
    _drawTopic(canvas, config, width, height);

    // 7. Draw main content
    await _drawContent(canvas, config, width, height);

    // 8. Draw hashtags
    _drawHashtags(canvas, config, width, height);

    // 9. Draw link
    if (config.link != null && config.link!.isNotEmpty) {
      _drawLink(canvas, config, width, height);
    }

    // 10. Draw date/time
    if (config.showDate || config.showTime) {
      _drawDateTime(canvas, config, width, height);
    }

    // 11. Draw decorative elements
    _drawDecorations(canvas, config, template, width, height);

    final picture = recorder.endRecording();
    final image = await picture.toImage(width, height);
    final byteData = await image.toByteData(format: ui.ImageByteFormat.png);

    if (byteData == null) return null;

    final pngBytes = byteData.buffer.asUint8List();

    // Convert to requested format
    return _convertFormat(pngBytes, config);
  }

  void _drawBackground(Canvas canvas, CardConfig config, Template template, int width, int height) {
    final rect = Rect.fromLTWH(0, 0, width.toDouble(), height.toDouble());

    if (template.gradientEndColor != null) {
      final gradient = LinearGradient(
        colors: [template.backgroundColor, template.gradientEndColor!],
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
      );
      final paint = Paint()
        ..shader = gradient.createShader(rect)
        ..style = PaintingStyle.fill;
      canvas.drawRect(rect, paint);
    } else {
      final paint = Paint()
        ..color = template.backgroundColor
        ..style = PaintingStyle.fill;
      canvas.drawRect(rect, paint);
    }

    // Subtle grid pattern for tech feel
    _drawGridPattern(canvas, width, height, config.accentColor);
  }

  void _drawGridPattern(Canvas canvas, int width, int height, Color accentColor) {
    final paint = Paint()
      ..color = accentColor.withOpacity(0.03)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 0.5;

    const spacing = 20.0;
    for (double x = 0; x < width; x += spacing) {
      canvas.drawLine(Offset(x, 0), Offset(x, height.toDouble()), paint);
    }
    for (double y = 0; y < height; y += spacing) {
      canvas.drawLine(Offset(0, y), Offset(width.toDouble(), y), paint);
    }
  }

  void _drawBorder(Canvas canvas, CardConfig config, int width, int height) {
    if (config.borderWidth <= 0) return;

    final rect = Rect.fromLTWH(
      config.borderWidth / 2,
      config.borderWidth / 2,
      width - config.borderWidth,
      height - config.borderWidth,
    );

    final paint = Paint()
      ..color = config.borderColor
      ..style = PaintingStyle.stroke
      ..strokeWidth = config.borderWidth;

    final radius = _getCornerRadius(config);

    if (radius > 0) {
      canvas.drawRRect(
        RRect.fromRectAndRadius(rect, Radius.circular(radius)),
        paint,
      );
    } else {
      canvas.drawRect(rect, paint);
    }
  }

  void _drawShadow(Canvas canvas, CardConfig config, int width, int height) {
    if (!config.shadowEnabled) return;

    final shadowPaint = Paint()
      ..color = config.shadowColor
      ..maskFilter = MaskFilter.blur(
        BlurStyle.normal,
        config.shadowBlur,
      );

    final shadowRect = Rect.fromLTWH(
      config.shadowOffsetX,
      config.shadowOffsetY,
      width.toDouble(),
      height.toDouble(),
    );

    final radius = _getCornerRadius(config);

    if (radius > 0) {
      canvas.drawRRect(
        RRect.fromRectAndRadius(shadowRect, Radius.circular(radius)),
        shadowPaint,
      );
    } else {
      canvas.drawRect(shadowRect, shadowPaint);
    }
  }

  Future<void> _drawUserInfo(Canvas canvas, CardConfig config, int width) async {
    const avatarSize = 56.0;
    const padding = 24.0;
    final startY = padding;

    // Draw avatar circle
    final avatarRect = Rect.fromLTWH(padding, startY, avatarSize, avatarSize);

    if (config.avatarBytes != null) {
      try {
        final codec = await ui.instantiateImageCodec(config.avatarBytes!);
        final frame = await codec.getNextFrame();
        final image = frame.image;

        final avatarPaint = Paint()
          ..isAntiAlias = true
          ..shader = ImageShader(
            image,
            TileMode.clamp,
            TileMode.clamp,
            Matrix4.identity().storage,
          );

        final path = Path()
          ..addOval(avatarRect);
        canvas.clipPath(path);
        canvas.drawRect(avatarRect, avatarPaint);
        canvas.restore();

        // Border around avatar
        final borderPaint = Paint()
          ..color = config.accentColor
          ..style = PaintingStyle.stroke
          ..strokeWidth = 2;
        canvas.drawCircle(
          Offset(padding + avatarSize / 2, startY + avatarSize / 2),
          avatarSize / 2,
          borderPaint,
        );
      } catch (_) {
        _drawDefaultAvatar(canvas, avatarRect, config);
      }
    } else {
      _drawDefaultAvatar(canvas, avatarRect, config);
    }

    // Draw name
    final nameText = config.name;
    final namePainter = TextPainter(
      text: TextSpan(
        text: nameText,
        style: TextStyle(
          color: config.textColor,
          fontSize: 18,
          fontWeight: FontWeight.bold,
          fontFamily: config.fontFamily,
        ),
      ),
      textDirection: TextDirection.ltr,
    );
    namePainter.layout(maxWidth: width - padding * 3 - avatarSize);
    namePainter.paint(canvas, Offset(padding + avatarSize + 12, startY + 6));

    // Draw handle
    final handleText = config.handle;
    final handlePainter = TextPainter(
      text: TextSpan(
        text: handleText,
        style: TextStyle(
          color: config.accentColor.withOpacity(0.8),
          fontSize: 13,
          fontFamily: config.fontFamily,
        ),
      ),
      textDirection: TextDirection.ltr,
    );
    handlePainter.layout(maxWidth: width - padding * 3 - avatarSize);
    handlePainter.paint(canvas, Offset(padding + avatarSize + 12, startY + 30));
  }

  void _drawDefaultAvatar(Canvas canvas, Rect rect, CardConfig config) {
    final paint = Paint()
      ..color = config.accentColor.withOpacity(0.2)
      ..style = PaintingStyle.fill;
    canvas.drawCircle(rect.center, rect.width / 2, paint);

    final borderPaint = Paint()
      ..color = config.accentColor
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2;
    canvas.drawCircle(rect.center, rect.width / 2, borderPaint);

    // User icon text
    final iconPainter = TextPainter(
      text: TextSpan(
        text: String.fromCharCode(Icons.person.codePoint),
        style: TextStyle(
          fontFamily: Icons.person.fontFamily,
          fontSize: 28,
          color: config.accentColor,
        ),
      ),
      textDirection: TextDirection.ltr,
    );
    iconPainter.layout();
    iconPainter.paint(
      canvas,
      Offset(rect.center.dx - iconPainter.width / 2, rect.center.dy - iconPainter.height / 2),
    );
  }

  Future<void> _drawLogo(Canvas canvas, CardConfig config, Template template, int width, int height) async {
    final logoSize = 40.0;
    final padding = 24.0;

    Offset position;
    switch (config.logoPlacement) {
      case 'Top Left':
        position = Offset(padding, padding);
        break;
      case 'Top Right':
        position = Offset(width - padding - logoSize, padding);
        break;
      case 'Bottom Left':
        position = Offset(padding, height - padding - logoSize);
        break;
      case 'Bottom Right':
      default:
        position = Offset(width - padding - logoSize, height - padding - logoSize);
        break;
    }

    // Draw OULECU text as logo
    final logoPainter = TextPainter(
      text: TextSpan(
        text: 'OULECU',
        style: TextStyle(
          color: config.accentColor.withOpacity(0.6),
          fontSize: 12,
          fontWeight: FontWeight.bold,
          fontFamily: 'JetBrainsMono',
          letterSpacing: 2,
        ),
      ),
      textDirection: TextDirection.ltr,
    );
    logoPainter.layout();
    logoPainter.paint(canvas, position);
  }

  void _drawTopic(Canvas canvas, CardConfig config, int width, int height) {
    const padding = 24.0;
    const startY = 100.0;

    // Topic
    if (config.topic.isNotEmpty) {
      final topicPainter = TextPainter(
        text: TextSpan(
          text: config.topic.toUpperCase(),
          style: TextStyle(
            color: config.accentColor,
            fontSize: 22,
            fontWeight: FontWeight.bold,
            fontFamily: config.fontFamily,
            letterSpacing: 2,
          ),
        ),
        textDirection: TextDirection.ltr,
      );
      topicPainter.layout(maxWidth: width - padding * 2);
      topicPainter.paint(canvas, Offset(padding, startY));
    }

    // Subtopic
    if (config.subtopic.isNotEmpty) {
      final subtopicPainter = TextPainter(
        text: TextSpan(
          text: config.subtopic,
          style: TextStyle(
            color: config.textColor.withOpacity(0.8),
            fontSize: 15,
            fontWeight: FontWeight.w500,
            fontFamily: config.fontFamily,
          ),
        ),
        textDirection: TextDirection.ltr,
      );
      subtopicPainter.layout(maxWidth: width - padding * 2);
      subtopicPainter.paint(canvas, Offset(padding, startY + 32));
    }
  }

  Future<void> _drawContent(Canvas canvas, CardConfig config, int width, int height) async {
    const padding = 24.0;
    const startY = 160.0;
    final contentWidth = width - padding * 2;

    // Content image
    double currentY = startY;
    if (config.contentImageBytes != null) {
      try {
        final codec = await ui.instantiateImageCodec(config.contentImageBytes!);
        final frame = await codec.getNextFrame();
        final image = frame.image;

        final imageHeight = (contentWidth * image.height / image.width).clamp(100.0, 400.0);

        final imageRect = Rect.fromLTWH(padding, currentY, contentWidth, imageHeight);
        final imagePaint = Paint()
          ..isAntiAlias = true
          ..filterQuality = FilterQuality.high;

        canvas.drawImageRect(
          image,
          Rect.fromLTWH(0, 0, image.width.toDouble(), image.height.toDouble()),
          imageRect,
          imagePaint,
        );

        currentY += imageHeight + 16;
      } catch (_) {
        // Skip image if can't load
      }
    }

    // Content text
    if (config.content.isNotEmpty) {
      final textPainter = TextPainter(
        text: TextSpan(
          text: config.content,
          style: TextStyle(
            color: config.textColor,
            fontSize: config.fontSize,
            fontWeight: config.fontWeight,
            fontStyle: config.fontStyle,
            fontFamily: config.fontFamily,
            height: 1.5,
          ),
        ),
        textDirection: TextDirection.ltr,
        textAlign: config.textAlign,
        maxLines: 20,
      );
      textPainter.layout(maxWidth: contentWidth);
      textPainter.paint(canvas, Offset(padding, currentY));
    }
  }

  void _drawHashtags(Canvas canvas, CardConfig config, int width, int height) {
    if (config.hashtags.isEmpty) return;

    const padding = 24.0;
    const tagHeight = 32.0;
    const tagSpacing = 8.0;
    final startY = height - 120.0;

    double currentX = padding;
    double currentY = startY;

    for (final tag in config.hashtags) {
      final tagText = tag.startsWith('#') ? tag : '#$tag';
      final textPainter = TextPainter(
        text: TextSpan(
          text: ' $tagText ',
          style: TextStyle(
            color: config.accentColor,
            fontSize: 13,
            fontWeight: FontWeight.w600,
            fontFamily: config.fontFamily,
          ),
        ),
        textDirection: TextDirection.ltr,
      );
      textPainter.layout();

      if (currentX + textPainter.width + tagSpacing > width - padding) {
        currentX = padding;
        currentY += tagHeight + tagSpacing;
      }

      // Tag background
      final tagRect = RRect.fromRectAndRadius(
        Rect.fromLTWH(currentX, currentY, textPainter.width, tagHeight - 4),
        const Radius.circular(4),
      );

      final tagPaint = Paint()
        ..color = config.accentColor.withOpacity(0.12)
        ..style = PaintingStyle.fill;
      canvas.drawRRect(tagRect, tagPaint);

      // Tag border
      final borderPaint = Paint()
        ..color = config.accentColor.withOpacity(0.3)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1;
      canvas.drawRRect(tagRect, borderPaint);

      textPainter.paint(canvas, Offset(currentX, currentY + 2));
      currentX += textPainter.width + tagSpacing;
    }
  }

  void _drawLink(Canvas canvas, CardConfig config, int width, int height) {
    if (config.link == null || config.link!.isEmpty) return;

    const padding = 24.0;
    final linkY = height - 60.0;

    // Chain link icon
    final iconPainter = TextPainter(
      text: TextSpan(
        text: String.fromCharCode(Icons.link.codePoint),
        style: TextStyle(
          fontFamily: Icons.link.fontFamily,
          fontSize: 14,
          color: config.accentColor,
        ),
      ),
      textDirection: TextDirection.ltr,
    );
    iconPainter.layout();
    iconPainter.paint(canvas, Offset(padding, linkY));

    // Link text
    final displayLink = config.link!.replaceAll(RegExp(r'^https?://'), '');
    final linkPainter = TextPainter(
      text: TextSpan(
        text: displayLink,
        style: TextStyle(
          color: config.accentColor.withOpacity(0.8),
          fontSize: 12,
          fontFamily: config.fontFamily,
          decoration: TextDecoration.underline,
        ),
      ),
      textDirection: TextDirection.ltr,
    );
    linkPainter.layout(maxWidth: width - padding * 3);
    linkPainter.paint(canvas, Offset(padding + 20, linkY + 2));
  }

  void _drawDateTime(Canvas canvas, CardConfig config, int width, int height) {
    if (!config.showDate && !config.showTime) return;

    const padding = 24.0;
    final dateY = height - 40.0;
    final now = DateTime.now();

    final parts = <String>[];
    if (config.showDate) {
      parts.add('${now.day.toString().padLeft(2, '0')}/${now.month.toString().padLeft(2, '0')}/${now.year}');
    }
    if (config.showTime) {
      parts.add('${now.hour.toString().padLeft(2, '0')}:${now.minute.toString().padLeft(2, '0')}');
    }

    final dateText = parts.join('  |  ');
    final datePainter = TextPainter(
      text: TextSpan(
        text: dateText,
        style: TextStyle(
          color: config.textColor.withOpacity(0.4),
          fontSize: 11,
          fontFamily: config.fontFamily,
        ),
      ),
      textDirection: TextDirection.ltr,
    );
    datePainter.layout();
    datePainter.paint(canvas, Offset(padding, dateY));
  }

  void _drawDecorations(Canvas canvas, CardConfig config, Template template, int width, int height) {
    // Corner accent marks
    final accentPaint = Paint()
      ..color = config.accentColor.withOpacity(0.15)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.5;

    const cornerSize = 24.0;

    // Top-left corner
    canvas.drawLine(const Offset(12, 36), const Offset(12, 12), accentPaint);
    canvas.drawLine(const Offset(12, 12), const Offset(36, 12), accentPaint);

    // Top-right corner
    canvas.drawLine(Offset(width - 36, 12), Offset(width - 12, 12), accentPaint);
    canvas.drawLine(Offset(width - 12, 12), Offset(width - 12, 36), accentPaint);

    // Bottom-left corner
    canvas.drawLine(Offset(12, height - 36), Offset(12, height - 12), accentPaint);
    canvas.drawLine(Offset(12, height - 12), Offset(36, height - 12), accentPaint);

    // Bottom-right corner
    canvas.drawLine(Offset(width - 36, height - 12), Offset(width - 12, height - 12), accentPaint);
    canvas.drawLine(Offset(width - 12, height - 12), Offset(width - 12, height - 36), accentPaint);

    // Subtle gold line at top
    final topLinePaint = Paint()
      ..shader = LinearGradient(
        colors: [
          Colors.transparent,
          config.accentColor.withOpacity(0.3),
          config.accentColor.withOpacity(0.3),
          Colors.transparent,
        ],
      ).createShader(Rect.fromLTWH(0, 0, width.toDouble(), 2));
    canvas.drawLine(
      const Offset(0, 0),
      Offset(width.toDouble(), 0),
      topLinePaint,
    );
  }

  double _getCornerRadius(CardConfig config) {
    switch (config.cornerStyle) {
      case 'Rounded':
        return config.cornerRadius;
      case 'Beveled':
        return config.cornerRadius * 0.5;
      case 'None':
      default:
        return 0;
    }
  }

  Future<Uint8List?> _convertFormat(Uint8List pngBytes, CardConfig config) async {
    if (config.exportFormats.isEmpty) return pngBytes;

    final format = config.exportFormats.first.toLowerCase();
    if (format == 'png') return pngBytes;

    try {
      final image = img.decodePng(pngBytes);
      if (image == null) return pngBytes;

      final quality = config.quality;

      switch (format) {
        case 'jpg':
        case 'jpeg':
          return Uint8List.fromList(img.encodeJpg(image, quality: quality));
        case 'webp':
          return Uint8List.fromList(img.encodePng(image));
        default:
          return pngBytes;
      }
    } catch (e) {
      debugPrint('Format conversion error: $e');
      return pngBytes;
    }
  }

  Future<Uint8List?> renderPreview(CardConfig config, Template template, {double scale = 0.3}) async {
    final previewConfig = config.copyWith(
      cardWidth: config.cardWidth * scale,
      cardHeight: config.cardHeight * scale,
      fontSize: config.fontSize * scale,
    );

    final width = previewConfig.cardWidth.toInt();
    final height = previewConfig.cardHeight.toInt();

    final recorder = ui.PictureRecorder();
    final canvas = Canvas(recorder);

    _drawBackground(canvas, previewConfig, template, width, height);
    _drawBorder(canvas, previewConfig, width, height);

    final picture = recorder.endRecording();
    final image = await picture.toImage(width, height);
    final byteData = await image.toByteData(format: ui.ImageByteFormat.png);

    return byteData?.buffer.asUint8List();
  }
}
